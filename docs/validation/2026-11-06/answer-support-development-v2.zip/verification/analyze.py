import collections
import hashlib
import json
from pathlib import Path
import sqlite3
import statistics
import sys

root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root))
from mnemos.judgment import Choice, guard_state
from mnemos.memory_safety import source_firewall
from mnemos.utils.ollama_judge import render_prompt

run = root / '.venv/answer-support-development-v2'
read = lambda name: json.loads((run / name).read_text(encoding='utf-8'))
lines = lambda name: [json.loads(line) for line in (run / name).read_text(encoding='utf-8').splitlines()]
manifest = read('manifest.json')
assert manifest['status'] == 'completed'
rows, requests, responses = (lines(name) for name in (
    'observations.jsonl', 'judge-requests.jsonl', 'provider-responses.jsonl'))
assert len(rows) == 320
assert hashlib.sha256((run / 'observations.jsonl').read_bytes()).hexdigest() == manifest['observations_sha256']
source_matches = all(hashlib.sha256((root / p).read_bytes()).hexdigest() == digest
    for p, digest in manifest['source_sha256'].items())
assert source_matches
treatments = {item['name'] for item in manifest['treatments']}
groups = collections.defaultdict(list)
for row in rows:
    groups[(row['repetition'], row['case_id'], row['query_id'], row['strategy'])].append(row)
assert len(groups) == 80
for group in groups.values():
    assert {row['treatment'] for row in group} == treatments
    for key in ('baseline_ids', 'baseline_facts', 'baseline_grade', 'snapshot_sha256', 'retrieval_ms'):
        assert all(row[key] == group[0][key] for row in group)
request_ids = [r['request_id'] for r in requests]
assert len(request_ids) == len(set(request_ids))
row_ids = [key for row in rows for key in row['judge_request_ids']]
assert collections.Counter(row_ids) == collections.Counter(request_ids)
response_ids = [r['support_request']['request_id'] for r in responses]
assert set(response_ids) <= set(request_ids)
request_by_id = {r['request_id']: r for r in requests}
responses_by_id = collections.defaultdict(list)
for response in responses:
    responses_by_id[response['support_request']['request_id']].append(response)
prompt_sizes = {}
for req in requests:
    questions = {key: Choice(q['instructions'], tuple(q['criteria'].items()))
        for key, q in req['questions'].items()}
    state, questions = guard_state(req['state'], questions, source_firewall())
    prompt = render_prompt(state, questions,
        require_choice_probabilities=req['treatment'] != 'legacy-batch')
    prompt_sizes[req['request_id']] = len(prompt.encode('utf-8'))
assert max(prompt_sizes.values()) <= manifest['judge_prompt_byte_limit']
stats, failure_rows = {}, []
for treatment in sorted(treatments):
    stats[treatment] = {}
    for strategy in ('vector', 'lexical', 'hybrid', 'full'):
        subset = [r for r in rows if r['treatment'] == treatment and r['strategy'] == strategy]
        assert len(subset) == 20
        ans = [r for r in subset if r['expected_fact_ids']]
        absent = [r for r in subset if not r['expected_fact_ids']]
        assert len(ans) == len(absent) == 10
        # Recompute the principal metrics directly from expected and returned IDs.
        hit = lambda r: r['support_status'] == 'assessed' and bool(set(r['supported_ids']) & set(r['expected_fact_ids']))
        clean = lambda r: r['support_status'] == 'assessed' and set(r['supported_ids']) == set(r['expected_fact_ids'])
        noanswer = lambda r: r['support_status'] == 'assessed' and not r['supported_ids']
        request_keys = [key for r in subset for key in r['judge_request_ids']]
        raw = [item for key in request_keys for item in responses_by_id[key]]
        ms = sorted(r['support_ms'] for r in subset)
        stats[treatment][strategy] = {
            'answerable_hits': sum(map(hit, ans)),
            'clean_answerable_hits': sum(map(clean, ans)),
            'correct_abstentions': sum(map(noanswer, absent)),
            'no_answer_false_answers': sum(bool(r['supported_ids']) for r in absent),
            'unsupported_returned_facts': sum(len(set(r['supported_ids']) - set(r['expected_fact_ids'])) for r in subset),
            'operational_failures': sum(r['support_status'] != 'assessed' for r in subset),
            'errors': dict(collections.Counter(r['support_error_type'] for r in subset if r['support_error_type'])),
            'requests': len(request_keys), 'raw_responses': len(raw),
            'support_ms_median': round(statistics.median(ms), 2),
            'support_ms_p95_nearest_rank': round(ms[18], 2),
            'support_ms_max': round(ms[-1], 2),
            'provider_prompt_eval_count': sum(r.get('prompt_eval_count', 0) for r in raw),
            'provider_prompt_eval_cached_count': sum(r.get('prompt_eval_cached_count', 0) for r in raw),
            'provider_eval_count': sum(r.get('eval_count', 0) for r in raw),
        }
        for row in subset:
            if row['support_status'] != 'assessed' or not clean(row):
                failure_rows.append({key: row[key] for key in (
                    'treatment', 'strategy', 'case_id', 'query_id', 'query', 'baseline_ids',
                    'expected_fact_ids', 'supported_ids', 'support_status',
                    'support_error_type', 'support_decisions', 'judge_request_ids')})

formats = collections.defaultdict(collections.Counter)
for resp in responses:
    treatment = resp['support_request']['treatment']
    req = request_by_id[resp['support_request']['request_id']]
    try:
        raw = json.loads(resp['response'])
    except (ValueError, TypeError):
        formats[treatment]['invalid_json_responses'] += 1
        continue
    for key, question in req['questions'].items():
        answer = raw.get(key, {})
        probabilities = answer.get('probabilities')
        if probabilities is None:
            formats[treatment]['omitted_distributions'] += 1
            continue
        formats[treatment]['supplied_distributions'] += 1
        if set(probabilities) != set(question['criteria']):
            formats[treatment]['incomplete_distributions'] += 1
        if abs(sum(probabilities.values()) - 1) > .01:
            formats[treatment]['nonunit_distributions'] += 1
        if probabilities.get(answer.get('choice'), -1) < max(probabilities.values(), default=0):
            formats[treatment]['chosen_not_highest'] += 1

database_checks = []
for path in sorted(run.glob('r*/*/accepted.sqlite')):
    # immutable avoids creating or changing SQLite sidecars in the frozen source.
    with sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True) as db:
        integrity = db.execute('PRAGMA integrity_check').fetchone()[0]
        assert integrity == 'ok'
        count = db.execute('SELECT COUNT(*) FROM memory_chunks').fetchone()[0]
    database_checks.append({'path': path.relative_to(run).as_posix(), 'integrity': integrity, 'facts': count})
assert len(database_checks) == 10
result = {
    'source_commit': manifest['source_commit'], 'source_hashes_match': source_matches,
    'verified_source_files': len(manifest['source_sha256']),
    'observations': len(rows), 'identical_baseline_groups': len(groups),
    'requests': len(requests), 'raw_responses': len(responses),
    'requests_without_raw_response': sorted(set(request_ids) - set(response_ids)),
    'duplicate_response_ids': {k: v for k, v in collections.Counter(response_ids).items() if v > 1},
    'max_rendered_prompt_bytes': max(prompt_sizes.values()),
    'max_provider_context_sequence': max(len(r.get('context', [])) for r in responses),
    'max_provider_prompt_eval_count': max(r.get('prompt_eval_count', 0) for r in responses),
    'max_provider_eval_count': max(r.get('eval_count', 0) for r in responses),
    'provider_done_reasons': dict(collections.Counter(r.get('done_reason') for r in responses)),
    'distribution_format': {key: dict(value) for key, value in formats.items()},
    'database_checks': database_checks, 'results': stats,
}
(run / 'verified-analysis.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
(run / 'failure-audit.json').write_text(json.dumps(failure_rows, indent=2), encoding='utf-8')
print(json.dumps({key: value for key, value in result.items() if key != 'results'}, indent=2))
for treatment, arms in stats.items():
    for strategy, values in arms.items():
        print(treatment, strategy, json.dumps(values))
