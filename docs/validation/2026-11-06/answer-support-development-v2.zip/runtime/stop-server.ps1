$ErrorActionPreference = 'Stop'
$runtimePath = Join-Path $PSScriptRoot 'support-runtime-v2'
$preflight = Get-Content -LiteralPath (Join-Path $runtimePath 'preflight.json') -Raw | ConvertFrom-Json -DateKind String
if ($preflight.status -ne 'ready') { throw 'No ready private server receipt' }
$ownedServer = Get-Process -Id $preflight.pid -ErrorAction Stop
$expectedStart = [DateTimeOffset]::Parse($preflight.started_utc).UtcDateTime
if ($ownedServer.Path -ne $preflight.binary -or [Math]::Abs(($ownedServer.StartTime.ToUniversalTime() - $expectedStart).TotalSeconds) -gt 10) {
    throw 'Process identity differs from the private server receipt'
}
$unload = Invoke-RestMethod -Uri ($preflight.endpoint + '/api/generate') -Method Post -ContentType 'application/json' -Body '{"model":"qwen3:4b","stream":false,"keep_alive":0}' -TimeoutSec 30
$activeModels = Invoke-RestMethod -Uri ($preflight.endpoint + '/api/ps') -TimeoutSec 10
if (@($activeModels.models).Count -ne 0) { throw 'Private model did not unload' }
Stop-Process -Id $preflight.pid
Wait-Process -Id $preflight.pid -Timeout 10 -ErrorAction SilentlyContinue
$serverStopped = $null -eq (Get-Process -Id $preflight.pid -ErrorAction SilentlyContinue)
$portClosed = $null -eq (Get-NetTCPConnection -State Listen -LocalPort 11436 -ErrorAction SilentlyContinue)
$receipt = [ordered]@{
    stopped_utc = [DateTimeOffset]::UtcNow.ToString('o')
    private_server_pid = $preflight.pid
    model_unloaded = (@($activeModels.models).Count -eq 0)
    server_stopped = $serverStopped
    port_closed = $portClosed
    unload_result = $unload
}
$receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $runtimePath 'cleanup.json') -Encoding utf8
$receipt | ConvertTo-Json -Depth 5
if (-not ($serverStopped -and $portClosed)) { throw 'Private server cleanup incomplete' }
