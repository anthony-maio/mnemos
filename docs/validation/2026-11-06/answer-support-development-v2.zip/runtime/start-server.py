import json
import os
from pathlib import Path
import socket
import subprocess
import time
from datetime import datetime, timezone

import httpx

root = Path(__file__).resolve().parent.parent
runtime = root / '.venv/support-runtime-v2'
runtime.mkdir(exist_ok=False)
endpoint = 'http://127.0.0.1:11436'
digest = '359d7dd4bcdab3d86b87d73ac27966f4dbb9f5efdfcc75d34a8764a09474fae7'
binary = Path(r'C:\Users\Ant\AppData\Local\Programs\Ollama\ollama.exe')
settings = {
    'OLLAMA_HOST': '127.0.0.1:11436',
    'OLLAMA_MODELS': str(root / '.venv/support-runtime/models'),
    'OLLAMA_CONTEXT_LENGTH': '16384',
    'OLLAMA_NUM_PARALLEL': '1',
    'OLLAMA_MAX_LOADED_MODELS': '1',
    'OLLAMA_KEEP_ALIVE': '1h',
    'OLLAMA_NO_CLOUD': '1',
}
with socket.socket() as port_check:
    port_check.bind(('127.0.0.1', 11436))
env = {**os.environ, **settings}
log = (runtime / 'server.log').open('xb')
process = subprocess.Popen([str(binary), 'serve'], env=env, cwd=root,
    stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
receipt = {'status': 'starting', 'started_utc': datetime.now(timezone.utc).isoformat(),
    'pid': process.pid, 'binary': str(binary), 'environment': settings,
    'endpoint': endpoint, 'expected_digest': digest}
receipt_path = runtime / 'preflight.json'
def save():
    receipt_path.write_text(json.dumps(receipt, indent=2), encoding='utf-8')
save()
try:
    with httpx.Client(trust_env=False, timeout=60) as client:
        for attempt in range(60):
            if process.poll() is not None:
                raise RuntimeError('Private server exited during startup')
            try:
                response = client.get(endpoint + '/api/version', timeout=1)
                response.raise_for_status()
                receipt['version'] = response.json()
                break
            except httpx.HTTPError:
                time.sleep(0.25)
        else:
            raise RuntimeError('Private server did not start')
        models = client.get(endpoint + '/api/tags').json()['models']
        model = next(item for item in models if item['name'] == 'qwen3:4b')
        if model['digest'] != digest:
            raise RuntimeError('Model digest differs from protocol')
        receipt['model'] = model
        response = client.post(endpoint + '/api/generate', json={
            'model': 'qwen3:4b', 'prompt': '', 'stream': False, 'keep_alive': '1h'})
        response.raise_for_status()
        receipt['warm_load'] = response.json()
        receipt['active_models'] = client.get(endpoint + '/api/ps').json()
        active = next(m for m in receipt['active_models']['models'] if m['digest'] == digest)
        if active['context_length'] != 16384:
            raise RuntimeError('Loaded model context differs from protocol')
        receipt['gpu'] = subprocess.check_output(['nvidia-smi',
            '--query-gpu=name,memory.total,driver_version', '--format=csv,noheader'], text=True).strip()
        receipt['status'] = 'ready'
        save()
        print(json.dumps({'status': 'ready', 'pid': process.pid,
            'version': receipt['version'], 'context_length': active['context_length'],
            'digest': active['digest'], 'gpu': receipt['gpu']}))
except BaseException as exc:
    receipt.update(status='failed', error_type=type(exc).__name__, error=str(exc))
    save()
    process.terminate()
    process.wait(timeout=10)
    raise
finally:
    log.close()
