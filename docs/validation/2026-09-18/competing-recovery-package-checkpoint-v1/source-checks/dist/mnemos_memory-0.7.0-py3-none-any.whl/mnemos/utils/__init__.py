"""
mnemos/utils/__init__.py — Public API for the utils package.
"""

from .embeddings import (
    EmbeddingProvider,
    OllamaEmbeddingProvider,
    OpenAIEmbeddingProvider,
    PrefixEmbeddingProvider,
    SimpleEmbeddingProvider,
    cosine_distance,
    cosine_similarity,
)
from .llm import (
    LLMProvider,
    MockLLMProvider,
    OllamaProvider,
    OpenAIProvider,
    UnavailableLLMProvider,
)
from .reliability import (
    MnemosConfigurationError,
    MnemosError,
    MnemosExternalServiceError,
    MnemosTransientError,
    RetryPolicy,
)
from .storage import InMemoryStore, MemoryStore, SQLiteStore

__all__ = [
    # Embeddings
    "EmbeddingProvider",
    "SimpleEmbeddingProvider",
    "OllamaEmbeddingProvider",
    "OpenAIEmbeddingProvider",
    "PrefixEmbeddingProvider",
    "cosine_similarity",
    "cosine_distance",
    # LLM
    "LLMProvider",
    "MockLLMProvider",
    "UnavailableLLMProvider",
    "OllamaProvider",
    "OpenAIProvider",
    # Reliability
    "MnemosError",
    "MnemosConfigurationError",
    "MnemosTransientError",
    "MnemosExternalServiceError",
    "RetryPolicy",
    # Storage
    "MemoryStore",
    "InMemoryStore",
    "SQLiteStore",
]
