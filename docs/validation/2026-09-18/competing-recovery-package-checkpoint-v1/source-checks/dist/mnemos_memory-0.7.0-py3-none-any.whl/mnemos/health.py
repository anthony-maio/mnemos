"""
mnemos/health.py — Readiness checks for the shipped local SQLite runtime.
"""

from __future__ import annotations

import importlib.util
import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

import httpx

from .settings import load_settings


def _resolve_env_value(
    name: str,
    *,
    env: Mapping[str, str] | None,
    default: str | None = None,
    aliases: tuple[str, ...] = (),
) -> str | None:
    source = env if env is not None else os.environ
    primary = source.get(name)
    if primary not in (None, ""):
        return primary
    for alias in aliases:
        value = source.get(alias)
        if value not in (None, ""):
            return value
    return default


def _module_available(module_name: str) -> bool:
    return importlib.util.find_spec(module_name) is not None


def _probe_http_provider(
    provider: str,
    base_url: str,
    *,
    api_key: str | None = None,
    model: str | None = None,
) -> tuple[str, str]:
    """Probe a provider only when explicitly requested by the caller."""
    headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
    endpoint = (
        f"{base_url.rstrip('/')}/api/tags"
        if provider == "ollama"
        else f"{base_url.rstrip('/')}/models"
    )
    try:
        response = httpx.get(endpoint, headers=headers, timeout=1.0)
        response.raise_for_status()
        if provider == "ollama":
            payload = response.json()
            models = payload.get("models", []) if isinstance(payload, dict) else []
            names = {str(item.get("name", "")) for item in models if isinstance(item, dict)}
            return "reachable", "ready" if not model or model in names else "model_missing"
        # OpenAI-compatible endpoints may not disclose model readiness.
        return "reachable", "not_checked"
    except Exception:
        return "unreachable", "unknown"


def _provider_state(
    provider: str,
    *,
    configured: bool,
    probe: bool,
    base_url: str | None = None,
    api_key: str | None = None,
    model: str | None = None,
) -> dict[str, Any]:
    if not configured:
        return {
            "provider": provider,
            "configured": False,
            "reachable": "not_applicable",
            "model_ready": "not_applicable",
            "status": "failed",
        }
    reachable = "not_checked"
    model_ready = "not_checked"
    if probe and base_url:
        reachable, model_ready = _probe_http_provider(
            provider, base_url, api_key=api_key, model=model
        )
    status = "configured"
    if reachable == "reachable" and model_ready in {"ready", "not_checked"}:
        status = "ready"
    elif reachable == "unreachable":
        status = "unreachable"
    elif model_ready == "model_missing":
        status = "model_missing"
    return {
        "provider": provider,
        "configured": True,
        "reachable": reachable,
        "model_ready": model_ready,
        "status": status,
    }


def _safe_int(value: str | None, default: int) -> int:
    if value is None or value == "":
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _safe_float(value: str | None, default: float) -> float:
    if value is None or value == "":
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _sqlite_chunk_count(db_path: Path) -> int | None:
    if not db_path.exists():
        return 0
    try:
        conn = sqlite3.connect(str(db_path))
        try:
            cursor = conn.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='memory_chunks'"
            )
            table_exists = int(cursor.fetchone()[0]) > 0
            if not table_exists:
                return 0
            return int(conn.execute("SELECT COUNT(*) FROM memory_chunks").fetchone()[0])
        finally:
            conn.close()
    except Exception:
        return None


def _sqlite_legacy_unscoped_chunk_count(db_path: Path) -> int | None:
    if not db_path.exists():
        return 0
    try:
        conn = sqlite3.connect(str(db_path))
        try:
            cursor = conn.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='memory_chunks'"
            )
            table_exists = int(cursor.fetchone()[0]) > 0
            if not table_exists:
                return 0

            count = 0
            for (metadata_json,) in conn.execute("SELECT metadata FROM memory_chunks"):
                if metadata_json in (None, ""):
                    count += 1
                    continue
                try:
                    metadata = json.loads(metadata_json)
                except Exception:
                    count += 1
                    continue
                if not isinstance(metadata, dict) or "scope" not in metadata:
                    count += 1
            return count
        finally:
            conn.close()
    except Exception:
        return None


def _embedding_provider_from_env(env: Mapping[str, str] | None = None) -> str:
    resolved = load_settings(env=env, default_store_type="sqlite")
    return resolved.settings.embedding.provider or "simple"


def detect_profile(
    env: Mapping[str, str] | None = None,
    *,
    default_store_type: str = "sqlite",
) -> str:
    """
    Return the current shipped runtime shape.
    """
    resolved = load_settings(
        env=env,
        default_store_type=default_store_type,  # type: ignore[arg-type]
    )
    _ = resolved.settings.storage.type
    return "default"


def run_health_checks(
    env: Mapping[str, str] | None = None,
    *,
    default_store_type: str = "sqlite",
    probe: bool = False,
) -> dict[str, Any]:
    """Evaluate configuration and optional provider readiness.

    Network/model probes are disabled by default and only run with
    ``probe=True``.  Their results remain separate from configuration checks.
    """
    checks: list[dict[str, str]] = []
    resolved = load_settings(
        env=env,
        default_store_type=default_store_type,  # type: ignore[arg-type]
    )
    settings = resolved.settings

    def add_check(name: str, status: str, message: str) -> None:
        checks.append({"name": name, "status": status, "message": message})

    profile = detect_profile(env, default_store_type=default_store_type)
    store_type = settings.storage.type
    llm_provider = settings.llm.provider
    embedding_provider = settings.embedding.provider or "simple"
    sqlite_chunk_threshold = _safe_int(
        _resolve_env_value(
            "MNEMOS_DOCTOR_CHUNK_THRESHOLD",
            env=env,
            default="5000",
        ),
        default=5000,
    )
    latency_p95_threshold_ms = _safe_float(
        _resolve_env_value(
            "MNEMOS_DOCTOR_LATENCY_P95_THRESHOLD_MS",
            env=env,
            default="250",
        ),
        default=250.0,
    )
    observed_latency_p95_ms_text = _resolve_env_value(
        "MNEMOS_DOCTOR_OBSERVED_P95_MS",
        env=env,
        default=None,
    )
    observed_latency_p95_ms = (
        None
        if observed_latency_p95_ms_text in (None, "")
        else _safe_float(observed_latency_p95_ms_text, default=0.0)
    )
    sqlite_chunk_count: int | None = None
    legacy_unscoped_chunks: int | None = None
    sqlite_vec_enabled = False
    provider_state: dict[str, dict[str, Any]] = {}

    if store_type == "memory":
        add_check(
            "store.memory",
            "warn",
            "InMemory store is non-persistent. Use sqlite for durable Mnemos storage.",
        )
    elif store_type == "sqlite":
        sqlite_path = settings.storage.sqlite_path
        parent = Path(sqlite_path).expanduser().resolve().parent
        if parent.exists():
            add_check("store.sqlite", "pass", f"SQLite backend ready at {sqlite_path}.")
        else:
            add_check(
                "store.sqlite",
                "warn",
                f"SQLite parent directory does not exist yet: {parent}",
            )
        sqlite_db_path = Path(sqlite_path).expanduser().resolve()
        sqlite_chunk_count = _sqlite_chunk_count(sqlite_db_path)
        legacy_unscoped_chunks = _sqlite_legacy_unscoped_chunk_count(sqlite_db_path)
        sqlite_vec_enabled = _module_available("sqlite_vec")
        if sqlite_vec_enabled:
            add_check(
                "store.sqlite.vec",
                "pass",
                "sqlite-vec dependency available for in-process vector acceleration.",
            )
        else:
            add_check(
                "store.sqlite.vec",
                "warn",
                "sqlite-vec is not installed; SQLite retrieval will fall back to Python similarity scan.",
            )
    else:
        add_check("store.type", "fail", f"Unsupported MNEMOS_STORE_TYPE: {store_type!r}")

    if llm_provider == "mock":
        add_check(
            "llm.mock",
            "warn",
            "Mock LLM provider is active. Cognitive modules run in degraded/mock mode.",
        )
        if store_type == "sqlite":
            add_check(
                "runtime.cognition",
                "fail",
                "Persistent SQLite runtime cannot be marked ready while mock cognition is active.",
            )
        provider_state["llm"] = _provider_state("mock", configured=False, probe=probe)
    elif llm_provider == "ollama":
        ollama_url = settings.base_url_for("ollama") or "http://localhost:11434"
        if ollama_url:
            add_check("llm.ollama", "pass", f"Ollama provider configured at {ollama_url}.")
            provider_state["llm"] = _provider_state(
                "ollama",
                configured=True,
                probe=probe,
                base_url=ollama_url,
                model=settings.llm.model,
            )
        else:
            add_check("llm.ollama", "fail", "MNEMOS_OLLAMA_URL is required for ollama provider.")
            provider_state["llm"] = _provider_state("ollama", configured=False, probe=probe)
    elif llm_provider == "openai":
        api_key = settings.api_key_for("openai")
        if api_key:
            add_check("llm.openai", "pass", "OpenAI provider API key configured.")
            provider_state["llm"] = _provider_state(
                "openai",
                configured=True,
                probe=probe,
                base_url=settings.base_url_for("openai"),
                api_key=api_key,
                model=settings.llm.model,
            )
        else:
            add_check(
                "llm.openai", "fail", "MNEMOS_OPENAI_API_KEY is required for openai provider."
            )
            provider_state["llm"] = _provider_state("openai", configured=False, probe=probe)
    elif llm_provider == "openclaw":
        api_key = settings.api_key_for("openclaw")
        if api_key:
            add_check("llm.openclaw", "pass", "OpenClaw provider API key configured.")
            provider_state["llm"] = _provider_state(
                "openclaw",
                configured=True,
                probe=probe,
                base_url=settings.base_url_for("openclaw"),
                api_key=api_key,
                model=settings.llm.model,
            )
        else:
            add_check(
                "llm.openclaw",
                "fail",
                "MNEMOS_OPENCLAW_API_KEY (or MNEMOS_OPENAI_API_KEY) is required for openclaw provider.",
            )
            provider_state["llm"] = _provider_state("openclaw", configured=False, probe=probe)
    elif llm_provider == "openrouter":
        api_key = settings.api_key_for("openrouter")
        if api_key:
            add_check("llm.openrouter", "pass", "OpenRouter provider API key configured.")
            provider_state["llm"] = _provider_state(
                "openrouter",
                configured=True,
                probe=probe,
                base_url=settings.base_url_for("openrouter"),
                api_key=api_key,
                model=settings.llm.model,
            )
        else:
            add_check(
                "llm.openrouter",
                "fail",
                "MNEMOS_OPENROUTER_API_KEY is required for openrouter provider.",
            )
            provider_state["llm"] = _provider_state("openrouter", configured=False, probe=probe)
    else:
        add_check("llm.provider", "fail", f"Unsupported MNEMOS_LLM_PROVIDER: {llm_provider!r}")
        provider_state["llm"] = _provider_state(llm_provider, configured=False, probe=probe)

    if embedding_provider == "simple":
        add_check(
            "embedding.simple",
            "warn",
            "Simple embeddings are for development; use openclaw/openai/ollama for production retrieval quality.",
        )
        provider_state["embedding"] = _provider_state("simple", configured=True, probe=probe)
    elif embedding_provider == "fastembed":
        if _module_available("fastembed"):
            add_check(
                "embedding.fastembed",
                "pass",
                "FastEmbed dependency is available; model readiness is reported separately.",
            )
            provider_state["embedding"] = _provider_state("fastembed", configured=True, probe=probe)
        else:
            add_check("embedding.fastembed", "fail", "FastEmbed is not installed.")
            provider_state["embedding"] = _provider_state(
                "fastembed", configured=False, probe=probe
            )
    elif embedding_provider == "ollama":
        ollama_url = settings.base_url_for("ollama") or "http://localhost:11434"
        if ollama_url:
            add_check(
                "embedding.ollama", "pass", f"Ollama embedding provider configured at {ollama_url}."
            )
            provider_state["embedding"] = _provider_state(
                "ollama",
                configured=True,
                probe=probe,
                base_url=ollama_url,
                model=settings.embedding.model,
            )
        else:
            add_check(
                "embedding.ollama",
                "fail",
                "MNEMOS_OLLAMA_URL is required for ollama embedding provider.",
            )
            provider_state["embedding"] = _provider_state("ollama", configured=False, probe=probe)
    elif embedding_provider == "openai":
        api_key = settings.api_key_for("openai")
        if api_key:
            add_check("embedding.openai", "pass", "OpenAI embedding provider API key configured.")
            provider_state["embedding"] = _provider_state(
                "openai",
                configured=True,
                probe=probe,
                base_url=settings.base_url_for("openai"),
                api_key=api_key,
                model=settings.embedding.model,
            )
        else:
            add_check(
                "embedding.openai",
                "fail",
                "MNEMOS_OPENAI_API_KEY is required for openai embedding provider.",
            )
            provider_state["embedding"] = _provider_state("openai", configured=False, probe=probe)
    elif embedding_provider == "openclaw":
        api_key = settings.api_key_for("openclaw")
        if api_key:
            add_check(
                "embedding.openclaw", "pass", "OpenClaw embedding provider API key configured."
            )
            provider_state["embedding"] = _provider_state(
                "openclaw",
                configured=True,
                probe=probe,
                base_url=settings.base_url_for("openclaw"),
                api_key=api_key,
                model=settings.embedding.model,
            )
        else:
            add_check(
                "embedding.openclaw",
                "fail",
                "MNEMOS_OPENCLAW_API_KEY (or MNEMOS_OPENAI_API_KEY) is required for openclaw embeddings.",
            )
            provider_state["embedding"] = _provider_state("openclaw", configured=False, probe=probe)
    elif embedding_provider == "openrouter":
        api_key = settings.api_key_for("openrouter")
        if api_key:
            add_check(
                "embedding.openrouter",
                "pass",
                "OpenRouter embedding provider API key configured.",
            )
            provider_state["embedding"] = _provider_state(
                "openrouter",
                configured=True,
                probe=probe,
                base_url=settings.base_url_for("openrouter"),
                api_key=api_key,
                model=settings.embedding.model,
            )
        else:
            add_check(
                "embedding.openrouter",
                "fail",
                "MNEMOS_OPENROUTER_API_KEY is required for openrouter embeddings.",
            )
            provider_state["embedding"] = _provider_state(
                "openrouter", configured=False, probe=probe
            )
    else:
        add_check(
            "embedding.provider", "fail", f"Unsupported embedding provider: {embedding_provider!r}"
        )
        provider_state["embedding"] = _provider_state(
            embedding_provider, configured=False, probe=probe
        )

    for index, warning in enumerate(resolved.warnings, start=1):
        add_check(f"config.warning.{index}", "warn", warning)

    size_threshold_exceeded = (
        store_type == "sqlite"
        and sqlite_chunk_count is not None
        and sqlite_chunk_count >= sqlite_chunk_threshold
    )
    latency_threshold_exceeded = (
        observed_latency_p95_ms is not None and observed_latency_p95_ms >= latency_p95_threshold_ms
    )

    if store_type == "sqlite":
        if legacy_unscoped_chunks is None:
            add_check(
                "scope.isolation",
                "warn",
                "Unable to inspect SQLite store for legacy unscoped chunks.",
            )
        elif legacy_unscoped_chunks > 0:
            add_check(
                "scope.isolation",
                "warn",
                f"Found {legacy_unscoped_chunks} legacy unscoped chunks. They are excluded from scoped recall and need read-only review before any explicit migration.",
            )
        else:
            add_check(
                "scope.isolation",
                "pass",
                "All SQLite chunks include scope metadata for v1 isolation.",
            )

        if size_threshold_exceeded or latency_threshold_exceeded:
            add_check(
                "store.sqlite.scale_signal",
                "warn",
                "SQLite chunk/latency threshold exceeded; inspect retrieval performance before shipping larger datasets.",
            )
        elif sqlite_chunk_count is not None:
            add_check(
                "store.sqlite.scale_signal",
                "pass",
                f"SQLite scale signal within threshold (chunks={sqlite_chunk_count}, threshold={sqlite_chunk_threshold}).",
            )
        else:
            add_check(
                "store.sqlite.scale_signal",
                "warn",
                "Unable to inspect SQLite scale signal from database.",
            )

    summary = {
        "pass": sum(1 for c in checks if c["status"] == "pass"),
        "warn": sum(1 for c in checks if c["status"] == "warn"),
        "fail": sum(1 for c in checks if c["status"] == "fail"),
    }

    if summary["fail"] > 0:
        status = "not_ready"
    elif summary["warn"] > 0:
        status = "degraded"
    else:
        status = "ready"

    recommendations: list[str] = []
    next_actions: list[str] = []

    def add_next_action(message: str) -> None:
        if message not in next_actions:
            next_actions.append(message)

    if llm_provider == "mock":
        recommendations.append(
            "Set MNEMOS_LLM_PROVIDER=openclaw (or openai/ollama) to enable non-mock cognition."
        )
        add_next_action(
            "Run `mnemos ui`, choose OpenClaw, OpenAI, or Ollama as the LLM provider, and save the global setup."
        )
    if embedding_provider == "simple":
        recommendations.append(
            "Set MNEMOS_EMBEDDING_PROVIDER=openclaw/openai/ollama for production retrieval quality."
        )
        add_next_action(
            "Switch embeddings from `simple` to OpenClaw, OpenAI, or Ollama before relying on Mnemos for daily retrieval."
        )
    if store_type == "memory":
        recommendations.append("Use SQLite for the shipped local-first persistence path.")
        add_next_action(
            "Run `mnemos ui` and keep the Starter SQLite preset so memory survives restarts in one local database."
        )
    if legacy_unscoped_chunks is not None and legacy_unscoped_chunks > 0:
        recommendations.append(
            "Legacy unscoped chunks are excluded from scoped recall. Review them in the read-only legacy view before an explicit migration."
        )
        add_next_action(
            "Review legacy unscoped chunks in the read-only legacy view; assign them only through an explicit reviewed migration."
        )
    if store_type == "sqlite":
        sqlite_path = settings.storage.sqlite_path
        parent = Path(sqlite_path).expanduser().resolve().parent
        if not parent.exists():
            add_next_action(
                f"Create the SQLite parent directory or update the configured path before relying on the current store location: {parent}"
            )
    if not sqlite_vec_enabled and store_type == "sqlite":
        recommendations.append(
            "sqlite-vec is optional, but installing it improves retrieval performance on larger local datasets."
        )
    if status != "ready" and not next_actions:
        add_next_action(
            "Run `mnemos ui` to review the current setup, then rerun `mnemos-cli doctor` after saving changes."
        )

    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "degraded_mode": status == "degraded",
        "profile": profile,
        "store_type": store_type,
        "llm_provider": llm_provider,
        "embedding_provider": embedding_provider,
        "upgrade_signals": {
            "sqlite_chunk_count": sqlite_chunk_count,
            "sqlite_chunk_threshold": sqlite_chunk_threshold,
            "observed_latency_p95_ms": observed_latency_p95_ms,
            "latency_p95_threshold_ms": latency_p95_threshold_ms,
            "threshold_exceeded": bool(size_threshold_exceeded or latency_threshold_exceeded),
        },
        "scope_isolation": {
            "legacy_unscoped_chunks": legacy_unscoped_chunks,
            "ready": not bool(legacy_unscoped_chunks),
        },
        "vector_acceleration": {
            "enabled": sqlite_vec_enabled,
            "provider": "sqlite-vec" if sqlite_vec_enabled else None,
        },
        "provider_state": provider_state,
        "probe_requested": probe,
        "summary": summary,
        "checks": checks,
        "recommendations": recommendations,
        "next_actions": next_actions,
    }
