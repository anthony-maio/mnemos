"""
mnemos/modules/surprisal.py — Surprisal-Triggered Encoding (Predictive Processing).

Neuroscience Basis:
    The brain operates on Predictive Coding (Friston, 2005; Clark, 2013).
    We constantly generate predictions about our sensory environment and
    only commit experiences to long-term memory when there is a *prediction
    error* — a significant mismatch between what was expected and what occurred.
    This is why mundane, expected events are forgotten while surprising,
    unexpected events are vividly remembered.

    The hippocampus acts as a 'novelty detector', firing strongly in response
    to prediction errors, triggering memory consolidation for surprising events.

Mnemos Implementation:
    A background LLM predicts the user's next intent given conversation history.
    When the user's actual input arrives, we compute the semantic distance
    (cosine distance in embedding space) between the prediction and reality.
    If this *surprisal score* exceeds the configured threshold, the interaction
    is committed to long-term memory with a high salience weight.

    Low surprisal (expected input) → discard (no memory encoding needed)
    High surprisal (unexpected input) → encode with high salience weight
"""

from __future__ import annotations

from collections import OrderedDict, deque
import hashlib
import json
from datetime import datetime, timezone
from typing import Any

from ..config import SurprisalConfig
from ..memory_safety import MemoryWriteFirewall
from ..scopes import interaction_partition
from ..types import Interaction, MemoryChunk, ProcessResult
from ..utils.embeddings import EmbeddingProvider, cosine_distance, embed_text_async
from ..utils.llm import LLMProvider
from ..utils.storage import MemoryStore


class SurprisalGate:
    """
    Surprisal-triggered memory encoding gate.

    Acts as the information-theoretic filter at the ingestion layer.
    Only interactions with semantic surprisal above the configured threshold
    are passed to long-term storage — mirroring the brain's efficiency in
    encoding only prediction errors, not mundane expected inputs.

    Args:
        llm: LLM provider used for next-intent prediction.
        embedder: Embedding provider for semantic distance calculation.
        store: Memory store where high-surprisal chunks are written.
        config: SurprisalConfig controlling thresholds and model settings.
    """

    def __init__(
        self,
        llm: LLMProvider,
        embedder: EmbeddingProvider,
        store: MemoryStore,
        config: SurprisalConfig | None = None,
        write_firewall: MemoryWriteFirewall | None = None,
    ) -> None:
        self._llm = llm
        self._embedder = embedder
        self._store = store
        self._config = config or SurprisalConfig()
        self._write_firewall = write_firewall or MemoryWriteFirewall()
        # Conversation history buffer — acts as hippocampal working memory
        self._history: deque[Interaction] = deque(maxlen=self._config.history_window)
        self._histories: OrderedDict[tuple[str, str, str, str], deque[Interaction]] = OrderedDict()
        self._predictions: dict[tuple[str, str, str, str], tuple[str, str]] = {}
        # Stats tracking
        self._total_processed: int = 0
        self._total_stored: int = 0

    def _prediction_history(self, interaction: Interaction) -> list[Interaction]:
        partition = interaction_partition(interaction.metadata)
        history = [
            turn
            for turn in self._histories.get(partition, ())
            if turn.timestamp < interaction.timestamp
        ]
        if len(history) >= self._config.history_window:
            return history[-self._config.history_window :]

        scope = str(interaction.metadata.get("scope", "project"))
        scope_id_raw = interaction.metadata.get("scope_id")
        scope_id = scope_id_raw if isinstance(scope_id_raw, str) else None
        persisted_history = self._store.list_episodic_events(
            scope=scope,
            scope_id=scope_id,
            limit=self._config.history_window,
            user_profile_id=interaction.metadata.get("user_profile_id"),
            session_id=interaction.metadata.get("session_id"),
            before=interaction.timestamp,
            newest_first=True,
        )
        for event in persisted_history:
            if interaction_partition(event.metadata) != partition:
                continue
            if event.occurred_at >= interaction.timestamp:
                continue
            persisted = Interaction(
                role=event.role,
                content=event.content,
                timestamp=event.occurred_at,
                metadata=event.metadata,
            )
            if not any(
                turn.timestamp == persisted.timestamp
                and turn.role == persisted.role
                and turn.content == persisted.content
                for turn in history
            ):
                history.append(persisted)
        history.sort(key=lambda turn: turn.timestamp)
        return history[-self._config.history_window :]

    def _build_prediction_prompt(
        self,
        current_interaction: Interaction,
        history: list[Interaction],
    ) -> str:
        """
        Build the LLM prompt for predicting the user's next intent.

        Includes recent conversation history to provide context for prediction,
        just as the brain uses contextual priming to generate predictions.

        Args:
            current_interaction: The interaction we're about to score.

        Returns:
            A formatted prompt string.
        """
        history_lines = []
        for turn in history:
            role_label = turn.role.capitalize()
            history_lines.append(f"{role_label}: {turn.content}")

        history_str = "\n".join(history_lines) if history_lines else "(No prior history)"

        return (
            "You are a predictive intent engine. Given the conversation history below, "
            "predict what the user will say or ask next. Be specific and concise. "
            "Output ONLY your prediction, nothing else.\n\n"
            f"Conversation history:\n{history_str}\n\n"
            "Predicted next user input:"
        )

    @staticmethod
    def _history_signature(history: list[Interaction]) -> str:
        serialized = [(turn.role, turn.timestamp.isoformat(), turn.content) for turn in history]
        return hashlib.sha256(json.dumps(serialized).encode("utf-8")).hexdigest()

    async def precompute_prediction(self, next_interaction: Interaction) -> bool:
        """Predict from earlier evidence; the supplied interaction's content is excluded."""
        history = self._prediction_history(next_interaction)
        try:
            prediction = await self._llm.predict(
                self._build_prediction_prompt(next_interaction, history)
            )
        except Exception:
            return False
        safety = self._write_firewall.apply(prediction)
        if not safety.allowed or not safety.content.strip():
            return False
        self._predictions[interaction_partition(next_interaction.metadata)] = (
            self._history_signature(history),
            safety.content,
        )
        if len(self._predictions) > 256:
            self._predictions.pop(next(iter(self._predictions)))
        return True

    async def _compute_surprisal(
        self, interaction: Interaction
    ) -> tuple[float | None, str, str | None, str]:
        """
        Compute the surprisal score for an interaction.

        Steps:
        1. Ask the LLM to predict the next user input from history
        2. Embed both the prediction and the actual input
        3. Return cosine distance between the two embeddings

        Args:
            interaction: The interaction to score.

        Returns:
            Surprisal score in [0, 2], typically [0, 1] for text embeddings.
            Higher = more surprising = higher salience.
        """
        history = self._prediction_history(interaction)
        cached = self._predictions.pop(interaction_partition(interaction.metadata), None)
        mode = "on_demand"

        # Step 1: Get prediction from LLM
        prediction_prompt = self._build_prediction_prompt(interaction, history)
        try:
            if cached is not None and cached[0] == self._history_signature(history):
                prediction = cached[1]
                mode = "cached"
            else:
                prediction = await self._llm.predict(prediction_prompt)
        except Exception:
            return None, "provider_unavailable", None, mode

        safe_prediction = self._write_firewall.apply(prediction)
        if not safe_prediction.allowed or not safe_prediction.content.strip():
            return None, "prediction_unavailable", None, mode
        prediction = safe_prediction.content

        # Step 2: Embed both prediction and actual input
        prediction_embedding = await embed_text_async(self._embedder, prediction, role="symmetric")
        actual_embedding = await embed_text_async(
            self._embedder, interaction.content, role="symmetric"
        )

        # Step 3: Cosine distance = semantic divergence = surprisal score
        return cosine_distance(prediction_embedding, actual_embedding), "measured", prediction, mode

    def _salience_from_surprisal(self, surprisal: float) -> float:
        """
        Convert a raw surprisal score to a [0, 1] salience weight.

        The salience function is sigmoid-like: scores near the threshold
        produce moderate salience; scores well above produce high salience.
        We normalize so that surprisal = 1.0 maps to salience ≈ 1.0.

        Args:
            surprisal: Raw cosine distance surprisal score.

        Returns:
            Salience weight in [0, 1].
        """
        # Simple linear normalization: clamp to [0, 1]
        return min(max(surprisal, 0.0), 1.0)

    async def process(
        self, interaction: Interaction, *, force_encode: bool = False
    ) -> ProcessResult:
        """
        Process an interaction through the surprisal gate.

        If the interaction's surprisal score exceeds the threshold, it is
        committed to long-term memory with a salience-weighted MemoryChunk.
        If below threshold, it is discarded (not stored).

        The interaction is always added to the history buffer regardless
        of whether it was stored — history is used for prediction context.

        Args:
            interaction: The interaction to evaluate and potentially store.

        Returns:
            ProcessResult indicating whether the interaction was stored,
            the resulting chunk (if stored), the surprisal score, and a reason.
        """
        self._total_processed += 1
        safety = self._write_firewall.apply(interaction.content)
        if not safety.allowed:
            return ProcessResult(stored=False, reason=f"Blocked by safety policy: {safety.reason}")
        interaction = interaction.model_copy(update={"content": safety.content})

        # Skip very short content (likely not meaningful)
        if not force_encode and len(interaction.content.strip()) < self._config.min_content_length:
            self.add_to_history(interaction)
            return ProcessResult(
                stored=False,
                salience=0.0,
                reason=f"Content too short (< {self._config.min_content_length} chars).",
            )

        # Compute surprisal score
        surprisal, surprisal_status, prediction, prediction_mode = (
            (None, "explicit_remember", None, "bypassed")
            if force_encode
            else await self._compute_surprisal(interaction)
        )
        diagnostics = {
            "surprisal_score": surprisal,
            "surprisal_status": surprisal_status,
            "prediction": prediction,
            "prediction_mode": prediction_mode,
            "prediction_model": getattr(self._llm, "model", type(self._llm).__name__),
            "threshold": self._config.threshold,
        }

        # Always update history buffer (even if not stored)
        self.add_to_history(interaction)

        if surprisal is None:
            if self._config.threshold > 0.0 and not force_encode:
                return ProcessResult(
                    stored=False,
                    salience=0.0,
                    diagnostics=diagnostics,
                    reason=(
                        "Surprisal unavailable "
                        f"({surprisal_status.replace('_', ' ')}); threshold "
                        f"{self._config.threshold:.3f} requires a measured score."
                    ),
                )
            salience = 1.0
        elif surprisal <= self._config.threshold:
            return ProcessResult(
                stored=False,
                salience=self._salience_from_surprisal(surprisal),
                diagnostics=diagnostics,
                reason=(
                    f"Low surprisal ({surprisal:.3f} ≤ threshold {self._config.threshold:.3f}). "
                    "Interaction matched prediction — not encoded."
                ),
            )
        else:
            salience = self._salience_from_surprisal(surprisal)

        # High surprisal: encode as a memory chunk
        embedding = await embed_text_async(self._embedder, interaction.content, role="document")
        scope = str(interaction.metadata.get("scope", "project"))
        scope_id_raw = interaction.metadata.get("scope_id")
        scope_id = scope_id_raw if isinstance(scope_id_raw, str) else None

        chunk = MemoryChunk(
            content=interaction.content,
            embedding=embedding,
            metadata={
                "source": "surprisal_gate",
                "original_timestamp": interaction.timestamp.isoformat(),
                **interaction.metadata,
            },
            salience=salience,
            surprisal_score=surprisal,
            surprisal_status=surprisal_status,
            last_observed_at=interaction.timestamp,
            observation_count=1,
        )

        if surprisal is not None:
            chunk.metadata["surprisal_score"] = surprisal
        chunk.metadata["surprisal_status"] = surprisal_status
        chunk.metadata["surprisal_threshold"] = self._config.threshold
        chunk.metadata["encoding_diagnostics"] = diagnostics

        chunk = self._store.upsert_canonical(chunk)
        self._total_stored += 1

        return ProcessResult(
            stored=True,
            chunk=chunk,
            salience=salience,
            diagnostics=diagnostics,
            reason=(
                (
                    f"High surprisal ({surprisal:.3f} > threshold {self._config.threshold:.3f}). "
                    f"Encoded with salience {salience:.3f}."
                )
                if surprisal is not None
                else (
                    "Stored by explicit remember; surprisal gate bypassed."
                    if force_encode
                    else (
                        "Stored because threshold 0.000 explicitly disables surprisal gating and "
                        f"the score was unavailable ({surprisal_status.replace('_', ' ')})."
                    )
                )
            ),
        )

    def add_to_history(self, interaction: Interaction) -> None:
        """
        Manually add an interaction to the history buffer without processing.

        Useful for seeding history with prior context (e.g., loading a saved session).

        Args:
            interaction: The interaction to add to history.
        """
        safety = self._write_firewall.apply(interaction.content)
        if not safety.allowed:
            return
        interaction = interaction.model_copy(update={"content": safety.content})
        self._history.append(interaction)
        partition = interaction_partition(interaction.metadata)
        history = self._histories.setdefault(partition, deque(maxlen=self._config.history_window))
        history.append(interaction)
        self._histories.move_to_end(partition)
        # Durable history restores evicted sessions; bound process-local state.
        while len(self._histories) > 256:
            self._histories.popitem(last=False)

    def clear_history(self) -> None:
        """Clear the conversation history buffer."""
        self._history.clear()
        self._histories.clear()
        self._predictions.clear()

    def get_history(self) -> list[Interaction]:
        """Return the current conversation history buffer as a list."""
        return list(self._history)

    def get_stats(self) -> dict[str, Any]:
        """Return statistics about the surprisal gate's processing."""
        store_rate = (
            self._total_stored / self._total_processed if self._total_processed > 0 else 0.0
        )
        return {
            "module": "SurprisalGate",
            "total_processed": self._total_processed,
            "total_stored": self._total_stored,
            "store_rate": round(store_rate, 4),
            "history_length": len(self._history),
            "threshold": self._config.threshold,
        }
